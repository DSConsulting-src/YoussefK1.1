﻿using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using TradeAggregator.App.Applications.Views;

namespace TradeAggregator.App.Presentation.Views
{
    public partial class AggregatorView : UserControl, IAggregatorView
    {
        public AggregatorView()
        {
            InitializeComponent();
        }

        private void OpenFileClick(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new OpenFileDialog
            {
                Filter = "XML files (*.xml)|*.xml"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                InputTxt.Text = openFileDialog.FileName;
            }
        }
    }
}
