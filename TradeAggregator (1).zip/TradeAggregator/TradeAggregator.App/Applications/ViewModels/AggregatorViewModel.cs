﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Waf.Foundation;
using System.Windows;
using MahApps.Metro.Controls;
using TradeAggregator.App.Applications.DataModel;
using TradeAggregator.Core.Contracts;
using TradeAggregator.Logger;
using TradeAggregator.Model;
using TradeAggregator.Reader.Contracts;

namespace TradeAggregator.App.Applications.ViewModels
{
    using System.Waf.Applications;
    using Views;

    public class AggregatorViewModel : ViewModel<IAggregatorView>
    {
        private readonly ITradeReader _tradeReader;
        private readonly ITradeAggregator _tradeAggregator;
        private readonly ILogger<AggregatorViewModel> _logger;

        public AggregatorViewModel(ILoggerFactory loggerFactory, IAggregatorView view, ITradeReader tradeReader, ITradeAggregator tradeAggregator) 
            : base(view)
        {
            _logger = loggerFactory.CreateLogger<AggregatorViewModel>();
            _tradeReader = tradeReader;
            _tradeAggregator = tradeAggregator;

            AggregateCommand = new DelegateCommand(Aggregate);
            TradeGroupCollection = new ObservableCollection<TradeGroupDataModel>();
        }

        public DelegateCommand AggregateCommand { get; }

        public ObservableCollection<TradeGroupDataModel> TradeGroupCollection { get; private set; }

        private void Aggregate(object inputUri)
        {
            TradeGroupCollection.Clear();

            TaskHelper.Run(() => GetTradeGroups(inputUri.ToString()), TaskScheduler.Current)
                .ContinueWith(task =>
                {
                    if (!task.IsCompleted) return;

                    foreach (var tradeGroup in task.Result)
                    {
                        Application.Current.Invoke(() => TradeGroupCollection.Add(new TradeGroupDataModel(tradeGroup)));
                    }
                });
        }

        private IEnumerable<TradeGroup> GetTradeGroups(string inputUri)
        {
            var tradeGroups = new List<TradeGroup>();

            try
            {
                _logger.Info($"Aggregate {inputUri}...");

                var trades = _tradeReader.ReadAll(inputUri);

                if (trades.Any())
                {
                    _logger.Info($"Aggregate {trades.Count} trades...");

                    tradeGroups = _tradeAggregator.Aggregate(trades).ToList();

                    if (!tradeGroups.Any())
                    {
                        _logger.Warn("No trade group aggregated.");
                    }
                }
                else
                {
                    _logger.Warn("No trade found.");
                }

                _logger.Info("Aggregate finished.");
            }
            catch (Exception e)
            {
                _logger.Error("Aggregate failed.", e);
            }

            return tradeGroups;
        }
    }
}
