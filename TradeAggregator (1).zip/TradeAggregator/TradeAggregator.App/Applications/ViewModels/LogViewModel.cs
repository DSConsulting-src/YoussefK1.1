﻿using System.Waf.Applications;
using TradeAggregator.App.Applications.Views;

namespace TradeAggregator.App.Applications.ViewModels
{
    public class LogViewModel : ViewModel<ILogView>
    {
        private string _log;

        public LogViewModel(ILogView view) : base(view)
        {

          
        }

        public string Log
        {
            get => _log;
            set => SetProperty(ref _log, value);
        }
    }
}
