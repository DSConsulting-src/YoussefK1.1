﻿using System.Waf.Applications;

namespace TradeAggregator.App.Applications.Views
{
    public interface IAggregatorView : IView
    {
    }
}
