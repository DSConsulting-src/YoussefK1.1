﻿using TradeAggregator.Model;
using TradeAggregator.Model.Enum;

namespace TradeAggregator.App.Applications.DataModel
{
    public class TradeGroupDataModel : System.Waf.Foundation.Model
    {
        private string _correlationId;
        private int _tradeNumber;
        private double _value;
        private TradeGroupState _state;

        public TradeGroupDataModel(TradeGroup trade)
        {
            CorrelationID = trade.CorrelationID;
            TradeNumber = trade.NumberOfTrades;
            Value = trade.Value;
            State = trade.State;
        }

        public string CorrelationID
        {
            get => _correlationId;
            set => SetProperty(ref _correlationId, value);
        }

        public int TradeNumber
        {
            get => _tradeNumber;
            set => SetProperty(ref _tradeNumber, value);
        }


        public double Value
        {
            get => _value;
            set => SetProperty(ref _value, value);
        }

        public TradeGroupState State
        {
            get => _state;
            set => SetProperty(ref _state, value);
        }


    }
}
