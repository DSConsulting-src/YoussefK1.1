﻿
using TradeAggregator.Logger;

namespace TradeAggregator.App.Applications.Controllers
{
    using ViewModels;

    internal class ApplicationController
    {
        private readonly ShellViewModel _shellViewModel;
        private readonly ILogger<ApplicationController> _logger;

        public ApplicationController(ILoggerFactory loggerFactory, ShellViewModel shellViewModel)
        {
            _logger = loggerFactory.CreateLogger<ApplicationController>();
            _shellViewModel = shellViewModel;
        }

        public void Initialize()
        {
            _logger.Info("Controller Initialize...");
        }

        public void Run()
        {
            _logger.Info("Controller Run.");
            _shellViewModel.Show();
        }

        public void Shutdown()
        {
            _logger.Info("Controller Shutdown.");
        }
    }
}
