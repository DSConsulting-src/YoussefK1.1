﻿using TradeAggregator.Core.Contracts;
using TradeAggregator.Model;
using TradeAggregator.Model.Enum;

namespace TradeAggregator.Core.Services
{
    public class TradeStateResolver : ITradeStateResolver
    {
        public TradeGroupState Resolve(TradeGroup tradeGroup)
        {
            if (tradeGroup.Count < tradeGroup.NumberOfTrades)
            {
                return TradeGroupState.Pending;
            }

            if (tradeGroup.Count == tradeGroup.NumberOfTrades && tradeGroup.Value <= tradeGroup.Limit)
            {
                return TradeGroupState.Accepted;
            }

            return TradeGroupState.Rejected;
        }
    }
}
