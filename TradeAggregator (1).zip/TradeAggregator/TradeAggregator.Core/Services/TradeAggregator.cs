﻿using System;
using System.Collections.Generic;
using System.Linq;
using TradeAggregator.Core.Contracts;
using TradeAggregator.Logger;
using TradeAggregator.Model;

namespace TradeAggregator.Core.Services
{
    public class TradeAggregator : ITradeAggregator
    {
        private readonly ITradeStateResolver _stateResolver;
        private readonly ILogger _logger;

        public TradeAggregator(ILoggerFactory loggerFactory, ITradeStateResolver stateResolver)
        {
            _logger = loggerFactory.CreateLogger<TradeAggregator>();
            _stateResolver = stateResolver;
        }

        public IEnumerable<TradeGroup> Aggregate(IEnumerable<Trade> trades)
        {
            if (trades == null) 
                throw new ArgumentNullException(nameof(trades));

            var tradeGroups = Enumerable.Empty<TradeGroup>();

            try
            {
                tradeGroups = trades
                    .GroupBy(x => new { x.CorrelationId, x.NumberOfTrades, x.Limit })
                    .Select(g => new TradeGroup
                    {
                        CorrelationID = g.Key.CorrelationId,
                        NumberOfTrades = g.Key.NumberOfTrades,
                        Limit = g.Key.Limit,
                        Count = g.Count(),
                        Value = g.Sum(i => i.Value),
                    })
                    .Select(ApplyState)
                    .OrderBy(i => i.CorrelationID);
            }
            catch (Exception e)
            {
                _logger.Error("Aggregate failed.", e);
            }
            
            return tradeGroups;
        }

        private TradeGroup ApplyState(TradeGroup tradeGroup)
        {
            tradeGroup.State = _stateResolver.Resolve(tradeGroup);

            return tradeGroup;
        }
    }
}
