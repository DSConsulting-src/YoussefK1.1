﻿using System;
using System.Linq;
using TradeAggregator.Core.Contracts;
using TradeAggregator.Logger;
using TradeAggregator.Reader.Contracts;
using TradeAggregator.Writer.Contracts;

namespace TradeAggregator.Core.Proxy
{
    public class TradeAggregatorProxy : ITradeAggregatorProxy
    {
        private readonly ILogger _logger;
        private readonly ITradeReader _tradeReader;
        private readonly ITradeAggregator _tradeAggregator;
        private readonly ITradeWriter _tradeWriter;
        private readonly ITradeGroupAggregator _tradeGroupAggregator;

        public TradeAggregatorProxy(
            ILoggerFactory loggerFactory, 
            ITradeReader tradeReader, 
            ITradeAggregator tradeAggregator, 
            ITradeWriter tradeWriter,
            ITradeGroupAggregator tradeGroupAggregator)
        {
            _logger = loggerFactory.CreateLogger<TradeAggregatorProxy>();
            _tradeReader = tradeReader;
            _tradeAggregator = tradeAggregator;
            _tradeWriter = tradeWriter;
            _tradeGroupAggregator = tradeGroupAggregator;
        }

        public void Aggregate(string inputUri)
        {
            _logger.Info("Getting started");

            try
            {
                _logger.Info($"Aggregate {inputUri}...");

                var trades = _tradeReader.ReadAll(inputUri);

                if (trades.Any())
                {
                    _logger.Info($"Aggregate {trades.Count} trades...");
                    var tradeGroups = _tradeAggregator.Aggregate(trades).ToList();

                    if (tradeGroups.Any())
                    {
                        _logger.Info($"Write {tradeGroups.Count} trade groups...");
                        _tradeWriter.Write(tradeGroups);
                    }
                    else
                    {
                        _logger.Warn("No trade group aggregated.");
                    }
                }
                else
                {
                    _logger.Warn("No trade found.");
                }

                _logger.Info("Aggregate finished.");
            }
            catch (Exception e)
            {
                _logger.Error("Aggregate failed.", e);
            }
        }

        /// <summary>
        /// Other Aggregate Implementation
        /// </summary>
        /// <param name="inputUri"></param>
        public void AnotherAggregate(string inputUri)
        {
            _logger.Info("Getting started");

            try
            {
                _logger.Info($"Aggregate {inputUri}...");
                var tradeGroups = _tradeGroupAggregator.Aggregate(inputUri).ToList();

                if (tradeGroups.Any())
                {
                    _logger.Info($"Write {tradeGroups.Count} trade groups...");
                    _tradeWriter.Write(tradeGroups);
                }
                else
                {
                    _logger.Warn("No trade group aggregated.");
                }
            }
            catch (Exception e)
            {
                _logger.Error("Trade Aggregate failed.", e);
            }
        }
    }
}
