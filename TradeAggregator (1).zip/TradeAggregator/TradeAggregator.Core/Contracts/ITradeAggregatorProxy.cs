﻿namespace TradeAggregator.Core.Contracts
{
    public interface ITradeAggregatorProxy
    {
        void Aggregate(string inputUri);

        void AnotherAggregate(string inputUri);
    }
}