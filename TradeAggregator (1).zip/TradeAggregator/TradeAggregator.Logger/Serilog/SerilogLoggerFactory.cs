﻿using Serilog;
using Serilog.Sinks.SystemConsole.Themes;

namespace TradeAggregator.Logger.Serilog
{
    using System.Text;
    using Common;

    public class SerilogLoggerFactory : ILoggerFactory
    {
        private readonly IConfigurationHelper _configurationHelper;
        private const string Format = "{UtcTimestamp:HH:mm:ss.fff} - [{Level:u4}] {LoggerName} - {Message:lj}{NewLine}{Exception}";
        private const string DefaultLogPath = "Server.log";

        public SerilogLoggerFactory(IConfigurationHelper configurationHelper)
        {
            _configurationHelper = configurationHelper;
            var loggerConfiguration = new LoggerConfiguration()
                .MinimumLevel.Information()
                .Enrich.With<UtcTimestampEnricher>()
                .WriteTo.Console(theme: AnsiConsoleTheme.Code)
                .WriteTo.Async(x => x.File(GetLogPath(), outputTemplate: Format, encoding: Encoding.UTF8));

            Log.Logger = loggerConfiguration.CreateLogger();
        }

        public ILogger<T> CreateLogger<T>()
        {
            return new SerilogLogger<T>(Log.Logger);
        }

        public ILogger CreateLogger(string name)
        {
            return new SerilogLogger(Log.Logger, name);
        }

        public void Dispose()
        {
            Log.CloseAndFlush();
        }

        private string GetLogPath()
        {
            var logPath = DefaultLogPath;

            if (!string.IsNullOrEmpty(_configurationHelper.LogUri))
            {
                logPath = _configurationHelper.LogUri;
            }

            return logPath;
        }
    }
}
