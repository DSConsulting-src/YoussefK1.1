﻿using System;

namespace TradeAggregator.Logger
{
    public interface ILoggerFactory : IDisposable
    {
        ILogger<T> CreateLogger<T>();

        ILogger CreateLogger(string name);
    }
}