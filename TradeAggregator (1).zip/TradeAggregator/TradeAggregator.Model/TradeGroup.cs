﻿using TradeAggregator.Model.Enum;

namespace TradeAggregator.Model
{
    public class TradeGroup
    {
        public TradeGroup() {}

        public TradeGroup(Trade trade)
        {
            CorrelationID = trade.CorrelationId;
            NumberOfTrades = trade.NumberOfTrades;
            Limit = trade.Limit;
            Value = trade.Value;
            Count = 1;
        }

        public string CorrelationID { get; set; }

        public int NumberOfTrades { get; set; }

        public double Limit { get; set; }

        public double Value { get; set; }

        public int Count { get; set; }

        public TradeGroupState State { get; set; }
    }
}