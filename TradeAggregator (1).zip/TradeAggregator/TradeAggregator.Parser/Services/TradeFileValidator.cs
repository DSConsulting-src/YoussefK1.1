﻿
using System.IO;
using TradeAggregator.Logger;
using TradeAggregator.Parser.Contracts;

namespace TradeAggregator.Parser.Services
{
    public class TradeFileValidator : ITradeFileValidator
    {
        private readonly ILogger _logger;
        private const string Extension = ".xml";
        
        public TradeFileValidator(ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger<TradeFileValidator>();
        }

        public bool IsValid(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                _logger.Error("Validation failed. File name cannot be null or empty.");
                return false;
            }

            if (!File.Exists(fileName))
            {
                _logger.Error("Validation failed. File not found.");
                return false;
            }

            var  fileExtension = Path.GetExtension(fileName);

            if (fileExtension != Extension)
            {
                _logger.Error("Validation failed. Only xml files are allowed.");
                return false;
            }

            //We can add schema validation here

            return true;
        }
    }
}
