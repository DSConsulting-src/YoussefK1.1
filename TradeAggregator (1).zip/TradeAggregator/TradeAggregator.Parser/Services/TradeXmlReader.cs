﻿namespace TradeAggregator.Reader.Services
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Xml;
    using System.Xml.Schema;
    using System.Xml.Serialization;
    using Logger;
    using Model;
    using Contracts;

    /// <summary>
    /// I combined reading and schema validation for better performance.
    /// </summary>
    public class TradeXmlReader : ITradeReader
    {
        private const string DefaultSchemaUri = "Schema.xsd";
        private const string TradeNodeName = "Trade";
        private readonly ILogger _logger;

        public TradeXmlReader(ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger<TradeXmlReader>();
        }


        public IList<Trade> ReadAll(string inputUri)
        {
            if (string.IsNullOrEmpty(inputUri))
                throw new ArgumentNullException(nameof(inputUri), "Input Uri cannot be null or empty.");

            if (!File.Exists(inputUri))
                throw new FileNotFoundException("Input Uri not found.", inputUri);

            if (!File.Exists(DefaultSchemaUri))
                throw new FileNotFoundException("Schema Uri not found.", DefaultSchemaUri);

            var trades = new List<Trade>();

            try
            {
                _logger.Info("Parse...");
                using (var reader = XmlReader.Create(inputUri, CreateReaderSetting()))
                {
                    var tradeSerializer = new XmlSerializer(typeof(Trade));

                    _logger.Info("Parse 'Trade' nodes....");
                    while (reader.ReadToFollowing(TradeNodeName))
                    {
                        var trade = (Trade)tradeSerializer.Deserialize(reader);
                        trades.Add(trade);
                    }

                    reader.Close();
                }

                _logger.Info($"Parse finished. {trades.Count} trades loaded.");
            }
            catch (XmlSchemaValidationException e)
            {
                _logger.Error($"Schema validation failed. {e.Message}", e);
            }
            catch (Exception e)
            {
                _logger.Error("Parse failed.", e);
            }

            return trades;
        }

        public IEnumerable<Trade> Read(string inputUri)
        {
            if (string.IsNullOrEmpty(inputUri))
                throw new ArgumentNullException(nameof(inputUri), "Input Uri cannot be null or empty.");

            if (!File.Exists(inputUri))
                throw new FileNotFoundException("Input Uri not found.", inputUri);

            if (!File.Exists(DefaultSchemaUri))
                throw new FileNotFoundException("Schema Uri not found.", DefaultSchemaUri);

            _logger.Info("Parse...");
            using (var reader = XmlReader.Create(inputUri, CreateReaderSetting()))
            {
                var tradeSerializer = new XmlSerializer(typeof(Trade));

                _logger.Info("Parse 'Trade' nodes....");
                while (reader.ReadToFollowing(TradeNodeName))
                {
                    yield return (Trade)tradeSerializer.Deserialize(reader);
                }
            }
        }


        private XmlReaderSettings CreateReaderSetting()
        {
            var settings = new XmlReaderSettings();

            settings.Schemas.Add(null, DefaultSchemaUri);
            settings.ValidationType = ValidationType.Schema;
            settings.ValidationEventHandler += ValidationEventHandler;
            settings.ValidationFlags |= XmlSchemaValidationFlags.ReportValidationWarnings;
            settings.ValidationFlags |= XmlSchemaValidationFlags.ProcessInlineSchema;
            settings.ValidationFlags |= XmlSchemaValidationFlags.ProcessSchemaLocation;

            return settings;
        }

        private void ValidationEventHandler(object sender, ValidationEventArgs e)
        {
            if (e.Severity == XmlSeverityType.Error)
            {
                throw new XmlSchemaValidationException($"{e.Message}");
            }

            _logger.Error($"Validation warning. {e.Message}");
        }
    }
}
