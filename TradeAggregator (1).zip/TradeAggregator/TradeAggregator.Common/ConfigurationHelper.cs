﻿namespace TradeAggregator.Common
{
    public class ConfigurationHelper : IConfigurationHelper
    {
        public string InputUri => AggregatorConfiguration.Current.InputUri;

        public string ResultUri => AggregatorConfiguration.Current.ResultUri;

        public string LogUri => AggregatorConfiguration.Current.LogUri;
    }
}