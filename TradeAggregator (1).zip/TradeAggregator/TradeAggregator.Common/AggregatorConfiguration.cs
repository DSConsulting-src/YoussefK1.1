﻿
using System.Configuration;

namespace TradeAggregator.Common
{
    public class AggregatorConfiguration : ConfigurationSection
    {
        public static AggregatorConfiguration Current => (AggregatorConfiguration)ConfigurationManager.GetSection("AggregatorConfiguration");

        [ConfigurationProperty("InputUri", IsRequired = true)]
        public string InputUri => this["InputUri"] as string;

        [ConfigurationProperty("ResultUri", IsRequired = true)]
        public string ResultUri => this["ResultUri"] as string;

        [ConfigurationProperty("LogUri", IsRequired = true)]
        public string LogUri => this["LogUri"] as string;

        [ConfigurationProperty("Delimiter", IsRequired = true)]
        public string Delimiter => this["Delimiter"] as string;

    }
}
