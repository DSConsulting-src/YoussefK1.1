﻿namespace TradeAggregator.Common
{
    public interface IConfigurationHelper
    {
        string InputUri { get; }

        string ResultUri { get; }

        string LogUri { get; }
    }
}