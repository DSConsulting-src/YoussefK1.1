
using TradeAggregator.Core.Services;

namespace TradeAggregator.Test.Core
{
    using Moq;
    using Model;
    using Model.Enum;
    using Xunit;

    public class TradeStateResolverTests
    {
        private readonly MockRepository _mockRepository;

        public TradeStateResolverTests()
        {
            _mockRepository = new MockRepository(MockBehavior.Default);
        }

        private TradeStateResolver CreateTradeStateResolver()
        {
            return new TradeStateResolver();
        }

        [Fact]
        public void TestPendingState()
        {
            var resolver = CreateTradeStateResolver();

            var tradeGroup = new TradeGroup { Count = 0, NumberOfTrades = 1 };

            var state = resolver.Resolve(tradeGroup);

            Assert.Equal(TradeGroupState.Pending, state);
        }

        [Fact]
        public void TestAcceptedState()
        {
            var resolver = CreateTradeStateResolver();
            
            var tradeGroup = new TradeGroup { Value = 100, Limit = 200 };

            var state = resolver.Resolve(tradeGroup);

            Assert.Equal(TradeGroupState.Accepted, state);
        }

        [Fact]
        public void TestRejectedState()
        {
            var resolver = CreateTradeStateResolver();
            
            var tradeGroup = new TradeGroup { Value = 200, Limit = 100 };

            var state = resolver.Resolve(tradeGroup);

            Assert.Equal(TradeGroupState.Rejected, state);
        }
    }
}
