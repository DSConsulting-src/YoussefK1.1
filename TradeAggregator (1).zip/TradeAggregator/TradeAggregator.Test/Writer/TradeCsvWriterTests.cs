using System;
using System.Collections.Generic;
using System.IO;
using Moq;
using TradeAggregator.Common;
using TradeAggregator.Logger;
using TradeAggregator.Model;
using TradeAggregator.Model.Enum;
using TradeAggregator.Writer.Services;
using Xunit;

namespace TradeAggregator.Test.Writer
{
    public class TradeCsvWriterTests
    {
        private readonly Mock<ILoggerFactory> _mockLoggerFactory;
        private readonly Mock<ILogger<TradeCsvWriter>> _mockLogger;
        private readonly Mock<IConfigurationHelper> _mockConfig;

        public TradeCsvWriterTests()
        {
            var mockRepository = new MockRepository(MockBehavior.Default);
            _mockLoggerFactory = mockRepository.Create<ILoggerFactory>();
            _mockLogger = mockRepository.Create<ILogger<TradeCsvWriter>>();
            _mockConfig = mockRepository.Create<IConfigurationHelper>();

            _mockConfig.Setup(x => x.ResultUri).Returns("result.csv");
            _mockLoggerFactory.Setup(x => x.CreateLogger<TradeCsvWriter>()).Returns(_mockLogger.Object);
        }

        private TradeCsvWriter CreateTradeCsvWriter()
        {
            return new TradeCsvWriter(_mockLoggerFactory.Object, _mockConfig.Object);
        }


        [Fact]
        public void TestWrite()
        {
            var tradeCsvWriter = CreateTradeCsvWriter();
            var path = "result.csv";

            var tradeGroups = new List<TradeGroup>
            {
                new TradeGroup {CorrelationID = "200", NumberOfTrades = 2, State = TradeGroupState.Pending},
                new TradeGroup {CorrelationID = "222", NumberOfTrades = 1, State = TradeGroupState.Rejected},
                new TradeGroup {CorrelationID = "234", NumberOfTrades = 3, State = TradeGroupState.Accepted}
            };

            tradeCsvWriter.Write(tradeGroups);

            var expectedContent =
                "CorrelationID,NumberOfTrades,State\r\n200,2,Pending\r\n222,1,Rejected\r\n234,3,Accepted\r\n";

            Assert.True(File.Exists(path));
            Assert.Equal(expectedContent, File.ReadAllText(path));
        }

        [Fact]
        public void TestNullTradeGroups()
        {
            var tradeCsvWriter = CreateTradeCsvWriter();

            Assert.Throws<ArgumentNullException>(() => tradeCsvWriter.Write(null));
        }
    }
}
