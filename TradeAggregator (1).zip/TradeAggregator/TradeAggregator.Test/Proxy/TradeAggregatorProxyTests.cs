using System.Collections.Generic;
using System.Linq;
using Moq;
using TradeAggregator.Core.Contracts;
using TradeAggregator.Core.Proxy;
using TradeAggregator.Logger;
using TradeAggregator.Model;
using TradeAggregator.Reader.Contracts;
using TradeAggregator.Writer.Contracts;
using Xunit;

namespace TradeAggregator.Test.Proxy
{
    public class TradeAggregatorProxyTests
    {
        private readonly MockRepository _mockRepository;
        
        private readonly Mock<ILoggerFactory> _mockLoggerFactory;
        private readonly Mock<ILogger<TradeAggregatorProxy>> _mockLogger;
        private readonly Mock<ITradeReader> _mockTradeReader;
        private readonly Mock<ITradeAggregator> _mockTradeAggregator;
        private readonly Mock<ITradeWriter> _mockTradeWriter;
        private readonly Mock<ITradeGroupAggregator> _mockTradeGroupAggregator;

        public TradeAggregatorProxyTests()
        {
            _mockRepository = new MockRepository(MockBehavior.Default);

            _mockLoggerFactory = _mockRepository.Create<ILoggerFactory>();
            _mockTradeReader = _mockRepository.Create<ITradeReader>();
            _mockTradeAggregator = _mockRepository.Create<ITradeAggregator>();
            _mockTradeWriter = _mockRepository.Create<ITradeWriter>();
            _mockTradeGroupAggregator = _mockRepository.Create<ITradeGroupAggregator>();

            _mockLogger = _mockRepository.Create<ILogger<TradeAggregatorProxy>>();
            _mockLoggerFactory.Setup(x => x.CreateLogger<TradeAggregatorProxy>()).Returns(_mockLogger.Object);
        }

        private TradeAggregatorProxy CreateProxy()
        {
            return new TradeAggregatorProxy(_mockLoggerFactory.Object, _mockTradeReader.Object, _mockTradeAggregator.Object, _mockTradeWriter.Object, _mockTradeGroupAggregator.Object);
        }

        [Fact]
        public void TestAggregateWhenTradeFound()
        {
            var proxy = CreateProxy();

            var trades = new List<Trade>
            {
                new Trade { CorrelationId = "1", Limit = 200, NumberOfTrades = 2, Value = 100 }
            };

            _mockTradeReader.Setup(x => x.ReadAll(It.IsAny<string>())).Returns(trades);

            proxy.Aggregate("Input.xml");

            _mockTradeAggregator.Verify(x=> x.Aggregate(It.IsAny<IEnumerable<Trade>>()), Times.Once);
        }

        [Fact]
        public void TestAggregateWhenTradeNotFound()
        {
            var proxy = CreateProxy();

            _mockTradeReader.Setup(x => x.ReadAll(It.IsAny<string>())).Returns(new List<Trade>());

            proxy.Aggregate("Input.xml");

            _mockTradeAggregator.Verify(x => x.Aggregate(It.IsAny<IEnumerable<Trade>>()), Times.Never);
            _mockLogger.Verify(x => x.Warn("No trade found."), Times.Once());
        }

        [Fact]
        public void TestAggregateWhenTradeAggregated()
        {
            var proxy = CreateProxy();

            var trade = new Trade {CorrelationId = "1", Limit = 200, NumberOfTrades = 2, Value = 100};

            var trades = new List<Trade> { trade };
            var tradeGroups = new List<TradeGroup> { new TradeGroup(trade) };

            _mockTradeReader.Setup(x => x.ReadAll(It.IsAny<string>())).Returns(trades);
            _mockTradeAggregator.Setup(x => x.Aggregate(It.IsAny<IEnumerable<Trade>>())).Returns(tradeGroups);

            proxy.Aggregate("Input.xml");

            _mockTradeWriter.Verify(x => x.Write(It.IsAny<IEnumerable<TradeGroup>>()), Times.Once);
        }

        [Fact]
        public void TestAggregateWhenTradeNotAggregated()
        {
            var proxy = CreateProxy();

            var trade = new Trade { CorrelationId = "1", Limit = 200, NumberOfTrades = 2, Value = 100 };
            var trades = new List<Trade> { trade };

            _mockTradeReader.Setup(x => x.ReadAll(It.IsAny<string>())).Returns(trades);
            _mockTradeAggregator.Setup(x => x.Aggregate(It.IsAny<IEnumerable<Trade>>())).Returns(Enumerable.Empty<TradeGroup>());

            proxy.Aggregate("Input.xml");

            _mockTradeWriter.Verify(x => x.Write(It.IsAny<IEnumerable<TradeGroup>>()), Times.Never);
            _mockLogger.Verify(x => x.Warn("No trade group aggregated."), Times.Once());
        }
    }
}
