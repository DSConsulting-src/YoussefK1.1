
using System;
using System.Collections.Generic;
using System.Linq;
using Moq;
using TradeAggregator.Core.Contracts;
using TradeAggregator.Logger;
using TradeAggregator.Model;
using Xunit;

namespace TradeAggregator.Test.Services
{
    using TradeAggregator.Core.Services;

    public class TradeAggregatorTests
    {
        private readonly Mock<ILoggerFactory> _mockLoggerFactory;
        private readonly Mock<ITradeStateResolver> _mockStateResolver;

        public TradeAggregatorTests()
        {
            var mockRepository = new MockRepository(MockBehavior.Default);
            _mockLoggerFactory = mockRepository.Create<ILoggerFactory>();
            _mockStateResolver = mockRepository.Create<ITradeStateResolver>();
        }

        private TradeAggregator CreateTradeAggregator()
        {
            return new TradeAggregator(_mockLoggerFactory.Object, _mockStateResolver.Object);
        }

        [Fact]
        public void TestAggregateTrades()
        {
            var tradeAggregator = CreateTradeAggregator();

            var groups = new List<Trade>
            {
                new Trade { CorrelationId = "1", Limit = 100, NumberOfTrades = 2, Value = 100},
                new Trade { CorrelationId = "1", Limit = 100, NumberOfTrades = 2, Value = 200},
                new Trade { CorrelationId = "2", Limit = 100, NumberOfTrades = 2, Value = 200},
                new Trade { CorrelationId = "2", Limit = 100, NumberOfTrades = 2, Value = 300},
            };

            var result = tradeAggregator.Aggregate(groups).ToList();

            Assert.NotNull(result);
            Assert.NotEmpty(result);
            Assert.Equal(2, result.Count);

            Assert.Equal("1", result[0].CorrelationID);
            Assert.Equal(100, result[0].Limit);
            Assert.Equal(2, result[0].NumberOfTrades);
            Assert.Equal(300, result[0].Value);

            Assert.Equal("2", result[1].CorrelationID);
            Assert.Equal(100, result[1].Limit);
            Assert.Equal(2, result[1].NumberOfTrades);
            Assert.Equal(500, result[1].Value);
        }

        [Fact]
        public void TestAggregateEmptyTrades()
        {
            var tradeAggregator = CreateTradeAggregator();
            var result = tradeAggregator.Aggregate(new List<Trade>());
            Assert.Empty(result);
        }

        [Fact]
        public void TestAggregateNullTrades()
        {
            var tradeAggregator = CreateTradeAggregator();
            Assert.Throws<ArgumentNullException>(() => tradeAggregator.Aggregate(null));
        }
    }
}
