
using System.IO;
using System.Xml.Schema;

namespace TradeAggregator.Test.Reader
{
    using System;
    using Moq;
    using Logger;
    using TradeAggregator.Reader.Services;
    using Xunit;

    public class TradeXmlReaderTests : IDisposable
    {
        private readonly MockRepository _mockRepository;
        private readonly Mock<ILoggerFactory> _mockLoggerFactory;
        private readonly Mock<ILogger<TradeXmlReader>> _mockLogger;

        public TradeXmlReaderTests()
        {
            _mockRepository = new MockRepository(MockBehavior.Default);
            _mockLoggerFactory = _mockRepository.Create<ILoggerFactory>();
            _mockLogger = _mockRepository.Create<ILogger<TradeXmlReader>>();
            _mockLoggerFactory.Setup(x => x.CreateLogger<TradeXmlReader>()).Returns(_mockLogger.Object);
        }

        private TradeXmlReader CreateReader()
        {
            return new TradeXmlReader(_mockLoggerFactory.Object);
        }

        [Fact]
        public void TestNullInputUri()
        {
            var tradeReader = CreateReader();

            var ex = Assert.Throws<ArgumentNullException>(() => tradeReader.ReadAll(null));

            Assert.Equal("Input Uri cannot be null or empty. (Parameter 'inputUri')", ex.Message);
        }

        [Fact]
        public void TestEmptyInputUri()
        {
            var tradeReader = CreateReader();

            var ex = Assert.Throws<ArgumentNullException>(() => tradeReader.ReadAll(string.Empty));

            Assert.Equal("Input Uri cannot be null or empty. (Parameter 'inputUri')", ex.Message);
        }

        [Fact]
        public void TestNotFoundInputUri()
        {
            var tradeReader = CreateReader();
            var dummyInputUri = "dummy";

            var ex = Assert.Throws<FileNotFoundException>(() => tradeReader.ReadAll(dummyInputUri));

            Assert.Equal("Input Uri not found.", ex.Message);

        }

        [Fact]
        public void TestReadAll()
        {
            var tradeXmlReader = CreateReader();

            var inputUri = "Resources\\ValidInput.xml";
            var validTradeCount = 5;

            var result = tradeXmlReader.ReadAll(inputUri);

            Assert.NotEmpty(result);
            Assert.Equal(validTradeCount, result.Count);
        }

        [Fact]
        public void TestSchemaValidationForRootNode()
        {
            var tradeXmlReader = CreateReader();
            var inputUri = "Resources\\InvalidRootNode.xml";

            var result = tradeXmlReader.ReadAll(inputUri);

            Assert.Empty(result);

            _mockLogger.Verify(x => x.Error("Schema validation failed. The 'Tradess' element is not declared.", It.IsAny<XmlSchemaValidationException>()));
        }

        [Fact]
        public void TestSchemaValidationForTradeNode()
        {
            var tradeXmlReader = CreateReader();

            var inputUri = "Resources\\InvalidChildNode.xml";

            var result = tradeXmlReader.ReadAll(inputUri);

            Assert.Empty(result);

            _mockLogger.Verify(x => x.Error("Schema validation failed. The element 'Trades' has invalid child element 'InvalidTrade'. List of possible elements expected: 'Trade'.", It.IsAny<XmlSchemaValidationException>()));
        }

        [Fact]
        public void TestSchemaValidationForTradeLimitValue()
        {
            var tradeXmlReader = CreateReader();

            var inputUri = "Resources\\InvalidTradeLimitValue.xml";

            var result = tradeXmlReader.ReadAll(inputUri);

            Assert.Empty(result);

            _mockLogger.Verify(x => x.Error("Schema validation failed. The 'Limit' attribute is invalid - The value '' is invalid according to its datatype 'http://www.w3.org/2001/XMLSchema:integer' - The string '' is not a valid Integer value.", It.IsAny<XmlSchemaValidationException>()));
        }

        
        [Fact]
        public void TestSchemaValidationForTradeNumber()
        {
            var tradeXmlReader = CreateReader();

            var inputUri = "Resources\\InvalidTradeNumber.xml";

            var result = tradeXmlReader.ReadAll(inputUri);

            Assert.Empty(result);

            _mockLogger.Verify(x => x.Error("Schema validation failed. The 'NumberOfTrades' attribute is invalid - The value '' is invalid according to its datatype 'http://www.w3.org/2001/XMLSchema:integer' - The string '' is not a valid Integer value.", It.IsAny<XmlSchemaValidationException>()));
        }
        
        public void Dispose()
        {
            _mockRepository.VerifyAll();
        }
    }
}
