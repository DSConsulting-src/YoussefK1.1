﻿
namespace TradeAggregator.Serializer
{
    using System.Collections.Generic;
    using System.Xml;
    using System.Xml.Schema;
    using System.Xml.Serialization;
    using Model;
    using Logger;

    public class TradeXmlParser : ITradeParser
    {
        private const string SchemaUri = "Schema.xsd";
        private const string TradeNodeName = "Trade";
        private readonly ILogger _logger;

        public TradeXmlParser(ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger<TradeXmlParser>();
        }


        public List<Trade> Parse(string fileName)
        {
            var trades = new List<Trade>();

            // Parse...
            using (var reader = XmlReader.Create(fileName, CreateReaderSetting()))
            {
                // trade Serializer...
                var tradeSerializer = new XmlSerializer(typeof(Trade));

                // Parse "Trade" nodes...
                while (reader.ReadToFollowing(TradeNodeName))
                {
                    var trade = (Trade)tradeSerializer.Deserialize(reader);
                    trades.Add(trade);
                }

                reader.Close();
            }

            return trades;

        }

        public IEnumerable<Trade> Read(string fileName)
        {
            // Parse...
            using (var reader = XmlReader.Create(fileName, CreateReaderSetting()))
            {
                // trade Serializer...
                var tradeSerializer = new XmlSerializer(typeof(Trade));

                // Parse "Trade" nodes...
                while (reader.ReadToFollowing(TradeNodeName))
                {
                    yield return (Trade)tradeSerializer.Deserialize(reader);
                }
            }
        }

        private XmlReaderSettings CreateReaderSetting()
        {
            var settings = new XmlReaderSettings();

            settings.Schemas.Add(null, SchemaUri);
            settings.ValidationType = ValidationType.Schema;
            settings.ValidationEventHandler += ValidationEventHandler;
            settings.ValidationFlags |= XmlSchemaValidationFlags.ReportValidationWarnings;
            settings.ValidationFlags |= XmlSchemaValidationFlags.ProcessInlineSchema;
            settings.ValidationFlags |= XmlSchemaValidationFlags.ProcessSchemaLocation;

            return settings;
        }

        private void ValidationEventHandler(object sender, ValidationEventArgs e)
        {
            if (e.Severity == XmlSeverityType.Error)
            {
                _logger.Error($"Validation failed. Please check your file format.");
                throw new XmlSchemaValidationException($"Validation failed. {e.Message}");
            }

            _logger.Error($"Validation warning. {e.Message}");
        }
    }
}
